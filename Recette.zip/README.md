# Recette (DEV)
Démarrage local: `source venv/bin/activate && python run.py`
